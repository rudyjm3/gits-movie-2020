export const TEST_IMAGE_URL = 'https://i.imgur.com/fsyrScY.jpg';
export const TEST_VIDEO_URL = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';
export const TEST_YOUTUBE_URL = 'https://www.youtube.com/watch?v=jNQXAC9IVRw';
