Value : Elements
## undefined: 
- Nav

## 0: 
- SlideNumber

## 1:
- DownEventDetector

## 2: 
- SourcesHoldersWrapper
- SourcesHolders (inherited from SourcesHoldersWrapper)
- Sources (inherited from SourcesHoldersWrapper)
- Toolbar
- SlideButtons

## 3: 
- SlideButtons
- Toolbar

## 4
- SwipingInvisibleHover
