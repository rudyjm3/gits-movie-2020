import { createAndAppendStyles } from "../createAndAppendStyles";

if (typeof document === "object") {
    createAndAppendStyles();
}
