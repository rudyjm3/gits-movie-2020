export const ANIMATION_TIME = 250;
