const sourcesBaseName = 'source';
export const SOURCE_MAIN_WRAPPERS = sourcesBaseName + 'MainWrappers';
export const SOURCE_ANIMATION_WRAPPERS = sourcesBaseName + 'AnimationWrappers';
