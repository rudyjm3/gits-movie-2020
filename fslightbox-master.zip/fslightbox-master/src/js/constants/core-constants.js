// sources types
export const IMAGE_TYPE = 'image';
export const VIDEO_TYPE = 'video';
export const YOUTUBE_TYPE = 'youtube';
export const CUSTOM_TYPE = 'custom';
export const INVALID_TYPE = 'invalid';
