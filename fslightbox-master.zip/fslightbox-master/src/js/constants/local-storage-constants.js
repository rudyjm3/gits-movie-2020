export const SOURCES_TYPES_KEY = 'fslightbox-types';
export const SCROLLBAR_WIDTH_KEY = 'fslightbox-scrollbar-width';
