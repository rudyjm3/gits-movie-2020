export const FSLIGHTBOX_STYLES_ID = 'fslightbox-styles';
